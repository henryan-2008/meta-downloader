// Cria o item no menu de contexto ao instalar a extensão
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "download-meta-ad-video",
    title: "Baixar vídeo do anúncio",
    contexts: ["page"],
    documentUrlPatterns: [
      "https://www.facebook.com/ads/library/*",
      "https://web.facebook.com/ads/library/*"
    ]
  });
  console.log("Extensão Meta Ad Video Downloader instalada com sucesso!");
});

// Função que será injetada na página para obter o src do vídeo
function getVideoSrc() {
  const video = document.querySelector("video");
  
  if (!video) {
    console.error("[Meta Ad Downloader] Nenhum elemento <video> encontrado na página.");
    return null;
  }

  const src = video.currentSrc || video.src;
  
  if (!src) {
    console.error("[Meta Ad Downloader] Elemento <video> encontrado, mas sem src válido.");
    return null;
  }

  console.log("[Meta Ad Downloader] Vídeo encontrado:", src);
  return src;
}

// Lida com o clique no menu de contexto
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "download-meta-ad-video") return;

  try {
    // Injeta o script na aba atual para obter o src do vídeo
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: getVideoSrc
    });

    const videoSrc = results[0]?.result;

    if (!videoSrc) {
      console.error("[Meta Ad Downloader] Não foi possível obter o src do vídeo.");
      return;
    }

    // Gera nome do arquivo com timestamp
    const timestamp = new Date().toISOString().slice(0, 19).replace(/[:-]/g, "").replace("T", "-");
    const filename = `meta-ad-${timestamp}.mp4`;

    // Inicia o download
    chrome.downloads.download({
      url: videoSrc,
      filename: filename,
      saveAs: false
    }, (downloadId) => {
      if (chrome.runtime.lastError) {
        console.error("[Meta Ad Downloader] Erro no download:", chrome.runtime.lastError.message);
      } else {
        console.log("[Meta Ad Downloader] Download iniciado! ID:", downloadId);
      }
    });

  } catch (error) {
    console.error("[Meta Ad Downloader] Erro ao executar script:", error);
  }
});
